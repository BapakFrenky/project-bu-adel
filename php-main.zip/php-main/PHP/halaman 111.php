<?php
//file 31
$siswa0 = "Andri";
$siswa1 = "Denky";
$siswa2 = "Doni";
$siswa3 = "Yuda";
$siswa4 = "Riska";

echo $siswa1;

//file 32

$siswa = array("Andri", "Denky", "Doni", "Yuda", "Riska");

echo $siswa[1];

//file 33
$siswa = array("Andri", "Denky", "Doni", "Yuda", "Riska");

echo $siswa[2];
echo "<br>";
echo "murid itu bernama $siswa[0]";

//file 34
$macam2 = array("121", "joko", 44.99, "belajar php", true);
echo $macam2[0];
echo "<br>";
echo $macam2[1];
echo "<br>";
echo $macam2[2];
echo "<br>";
echo $macam2[3];
echo "<br>";
echo $macam2[4];
echo "<br>";
?>

?>