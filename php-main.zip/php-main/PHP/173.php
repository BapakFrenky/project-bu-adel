<?php
for ($i = 1; $i <= 21; $i = $i + 2){
    echo "induk semut beranak $i <br>";
}

?>