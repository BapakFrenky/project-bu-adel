<?php
$situs = "www.dunialkom.com";
$belajar1 ='sedang belajar programming di $situs';
echo $belajar1;

echo "<br>";

$belajar2 = "sedang belajar programming di $situs";
echo $belajar2;
?>