<?php
for ($i = 9; $i > 0; $i --){
    echo "anak ayam turun $i <br>";
}

?>  