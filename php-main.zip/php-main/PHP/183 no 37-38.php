<?php
//37
$i = 1000;
do {
    echo "$i";
    echo "akan tampil di browser <br>";
    $i = $i+1;
} while ($i <= 10);


//38

$nama = array("andri","joko","sukma","rina","sari");
for ($i = 0; $i < 5; $i++){
    echo "$nama[$i] <br>";
}
?>