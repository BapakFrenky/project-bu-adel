<?php
// Fungsi pertama
function salam_pagi() {
    echo "<p>Selamat pagi</p>";
}

salam_pagi();

// Fungsi kedua
function salam() {
    echo "<p>Selamat pagi</p>";
}

salam();
salam();
salam();
?>
